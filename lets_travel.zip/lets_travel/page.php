<?php include ("./inc/header.inc.php"); ?>
<?php
$to=$user;
if (isset($_GET['u'])) { 
    $to = mysql_real_escape_string($_GET['u']);  
    if (ctype_alnum($to)) {
    //check user exists
    $check = mysql_query("SELECT id, page_name FROM page WHERE page_name='$to'");
    if (mysql_num_rows($check)===1) {
        $get = mysql_fetch_assoc($check);
        $to = $get['page_name'];
        $id = $get['id'];
    }

    else
    {
        echo "<meta http-eqiuv=\"refresh\" content=\"0; url=http://localhost/lets_travel/index.php>";
        exit();
    }
    }
}

$post = @$_POST['post'];
if ($post != "") {
    $date_added = date("Y-m-d");
    $added_by = $user;
    $user_posted_to = $to;
    
    $sqlCommand = "INSERT INTO posts VALUES('','$post','','$date_added','$added_by','$user_posted_to')";
    $query = mysql_query($sqlCommand) or die(mysql_error());
}

//upload image code 
if (isset($_POST['uploadpic'])) {
        if (((@$_FILES["profilepic"]["type"]=="image/jpeg") || (@$_FILES["profilepic"]["type"]=="image/png") || (@$_FILES["profilepic"]["type"]=="image/gif"))&&(@$_FILES["profilepic"]["size"] < 1048576)) //1 Megabyte
  {
   $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
   $rand_dir_name = substr(str_shuffle($chars), 0, 15);
   mkdir("userdata/user_photos/$rand_dir_name",0777,true);

   if (file_exists("userdata/user_photos/$rand_dir_name/".@$_FILES["profilepic"]["name"]))
   {
    echo @$_FILES["profilepic"]["name"]." Already exists";
   }
   else
   {
    move_uploaded_file(@$_FILES["profilepic"]["tmp_name"],"userdata/user_photos/$rand_dir_name/".$_FILES["profilepic"]["name"]);
    //echo "Uploaded and stored in: userdata/profile_pics/$rand_dir_name/".@$_FILES["profilepic"]["name"];
    $profile_pic_name = @$_FILES["profilepic"]["name"];
    $img_id = "$rand_dir_name/$profile_pic_name";

    $date_added = date("Y-m-d");
    $added_by = $user;
    $user_posted_to = $to;
    
    $sqlCommand = "INSERT INTO posts VALUES('','','$img_id','$date_added','$added_by','$user_posted_to')";
    $query = mysql_query($sqlCommand) or die(mysql_error());
   }
}
}

 //Check whether the user has uploaded a profile pic or not
//changed from $user to $to
  $check_pic = mysql_query("SELECT profile_pic FROM page WHERE page_name='$to'");
  $get_pic_row = mysql_fetch_assoc($check_pic);
  $profile_pic_db = $get_pic_row['profile_pic'];
  if ($profile_pic_db == "") {
  $profile_pic = "img/default_pic.jpg";
  }
  else
  {
  $profile_pic = "pagedata/profile_pics/".$profile_pic_db;
  }

?>
<div id="status"></div>
<div class="postForm">
<form action="<?php echo "page.php?u=".$to; ?>" method="POST">    
    <textarea id="post" name="post" rows="4" cols="90"></textarea>
    <input type="submit" name="send" value="post" style="background-color: #DCE5EE; float: right; border: 1px solid #666; color:#666; height:73px; width:65px;"/>
</form>

<form action="" method="POST" enctype="multipart/form-data">
<input type="file" name="profilepic" />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="uploadpic" value="Upload Image">
</form>
</div>
<div class="profilePosts">
<?php
//changed from $user to $to
$getposts = mysql_query("SELECT * FROM posts WHERE user_posted_to='$to' ORDER BY pid DESC LIMIT 10") or die (mysql_error())  ;
while ($row = mysql_fetch_assoc($getposts)) {
    $pid = $row['pid'];
    $body = $row['body'];
    $photo = $row['photo'];
    $date_added = $row['date_added'];
    $added_by = $row['added_by'];
    $user_posted_to = $row['user_posted_to'];

    $get_user_info = mysql_query("SELECT * FROM users WHERE username='$added_by'");
    $get_info = mysql_fetch_assoc($get_user_info);
    $profilepic_info = $get_info['profile_pic'];
    if ($profilepic_info == "") {
     $profilepic_info = "./img/default_pic.jpg";
    }
    else
    {
     $profilepic_info = "./userdata/profile_pics/".$profilepic_info;
    }

    if ($photo == "") {   
    echo "
          <div style='float: left;'>
          <img src='$profilepic_info' height='60' width='60'>
          </div>
          <div class='posted_by'>
          Posted by:
          <a href='$added_by'>$added_by</a> on $date_added</div>
          <br /><br />
          <div  style='max-width: 600px;'>
          $body<br /><p /><p />
          </div>
          <br /><br />
          <hr />
    ";
    }
    else {
      $photo = "./userdata/user_photos/".$photo;
      echo "
          <div style='float: left;'>
          <img src='$profilepic_info' height='60' width='60'>
          </div>
          <div class='posted_by'>
          Posted by:
          <a href='$added_by'>$added_by</a> on $date_added</div>
          <br /><br />
          <div  style='max-width: 600px;'>
          <img src='$photo' height='60' width='60'>
          <br /><p /><p />
          </div>
          <br />
          <hr />
    ";
    }
}


$errorMsg = "";
/*  if (isset($_POST['follow'])) {
     $friend_request = $_POST['follow'];
     $errorMsg = "You followed the page!";
  }
  else
  {
   //Do nothing
  }
 */



 if (isset($_POST['follow'])) {
  //Pages follow for logged in user
  $follow_check = mysql_query("SELECT pages_follow FROM users WHERE username='$user'");
  $get_follow_row = mysql_fetch_assoc($follow_check);
  $follow_array = $get_follow_row['pages_follow'];
  $follow_array_explode = explode(",",$follow_array);
  $follow_array_count = count($follow_array_explode);
  
  //Follow array for page who follows page
  $follow_check_pagename = mysql_query("SELECT follow_array FROM page WHERE page_name='$to'");
  $get_follow_row_pagename = mysql_fetch_assoc($follow_check_pagename);
  $follow_array_pagename = $get_follow_row_pagename['follow_array'];
  $follow_array_explode_pagename = explode(",",$follow_array_pagename);
  $follow_array_count_pagename = count($follow_array_explode_pagename);

  if ($follow_array == "") {
     $follow_array_count = count(NULL);
  }
  if ($follow_array_pagename == "") {
     $follow_array_count_pagename = count(NULL);
  }
  if ($follow_array_count == NULL) {
   $add_friend_query = mysql_query("UPDATE users SET pages_follow=CONCAT(pages_follow,'$to') WHERE username='$user'");
  }
  if ($follow_array_count_pagename == NULL) {
   $add_friend_query = mysql_query("UPDATE page SET follow_array=CONCAT(follow_array,'$user') WHERE page_name='$to'");
  }
  if ($follow_array_count >= 1) {
   $add_friend_query = mysql_query("UPDATE users SET pages_follow=CONCAT(pages_follow,',$to') WHERE username='$user'");
  }
  if ($follow_array_count_pagename >= 1) {
   $add_friend_query = mysql_query("UPDATE page SET follow_array=CONCAT(follow_array,',$user') WHERE page_name='$to'");
  } 
  $errorMsg = "You followed the page!";
}


?>


</div>
<img src="<?php echo $profile_pic; ?>" height="200" width="200" alt="<?php echo $to; ?>'s Profile" title="<?php echo $to; ?>'s Profile"/>
<br />
<form action="<?php echo "page.php?u=".$to; ?>" method="POST">
<?php

	$followArray = "";
	$countFollows = "";
	$followArray12 = "";
	$addAsFollow = "";
	$selectFollowsQuery = mysql_query("SELECT follow_array FROM page WHERE page_name='$to'");
	$followRow = mysql_fetch_assoc($selectFollowsQuery);
	$followArray = $followRow['follow_array'];
	if ($followArray != "") {
	   $followArray = explode(",",$followArray);
	   $countFollows = count($followArray);
	   $followArray12 = array_slice($followArray, 0, 12);

	$i = 0;
	if (in_array($user,$followArray)) {
	 $addAsFollow = '<input type="submit" name="unfollow" value="Unfollow">';
	}
	else
	{ 
	 $addAsFollow = '<input type="submit" name="follow" value="Follow">';
	} 
	echo $addAsFollow;
	}
	else
	{
	 $addAsFollow = '<input type="submit" name="follow" value="Follow">';
	 echo $addAsFollow;
	}
//$user = logged in user
//$to = user who owns profile

if (@$_POST['unfollow']) {
  //Friend array for logged in user
  $follow_check = mysql_query("SELECT pages_follow FROM users WHERE username='$user'");
  $get_follow_row = mysql_fetch_assoc($follow_check);
  $follow_array = $get_follow_row['pages_follow'];
  $follow_array_explode = explode(",",$follow_array);
  $follow_array_count = count($follow_array_explode);
  
  //Friend array for user who owns profile
  $follow_check_pagename = mysql_query("SELECT follow_array FROM page WHERE page_name='$to'");
  $get_follow_row_pagename = mysql_fetch_assoc($follow_check_pagename);
  $follow_array_pagename = $get_follow_row_pagename['follow_array'];
  $follow_array_explode_pagename = explode(",",$follow_array_pagename);
  $follow_array_count_pagename = count($follow_array_explode_pagename);
  
  $usernameComma = ",".$to;
  $usernameComma2 = $to.",";
  
  $userComma = ",".$user;
  $userComma2 = $user.",";
  
  if (strstr($follow_array,$usernameComma)) {
   $friend1 = str_replace("$usernameComma","",$follow_array);
  }
  else
  if (strstr($follow_array,$usernameComma2)) {
   $friend1 = str_replace("$usernameComma2","",$follow_array);
  }
  else
  if (strstr($follow_array,$to)) {
   $friend1 = str_replace("$to","",$follow_array);
  }
  //Remove logged in user from other persons array
  if (strstr($follow_array,$userComma)) {
   $friend2 = str_replace("$userComma","",$follow_array);
  }
  else
  if (strstr($follow_array,$userComma2)) {
   $friend2 = str_replace("$userComma2","",$follow_array);
  }
  else
  if (strstr($follow_array,$user)) {
   $friend2 = str_replace("$user","",$follow_array);
  }

  $friend2 = "";

  $unfollowQuery = mysql_query("UPDATE users SET pages_follow='$friend1' WHERE username='$user'");
  $unfollowQuery_pagename = mysql_query("UPDATE page SET follow_array='$friend2' WHERE page_name='$to'");
  $errorMsg = "Page Unfollowed ...";
  //echo "Page Unfollowed ...";
  header("Location: page.php?u=$to");
}
?>
<?php echo $errorMsg; ?>

</form>

<div class="textHeader"><?php echo $to; ?>'s Profile</div>
<div class="profileLeftSideContent">
<?php
//changed from $user to $to
    $about_query = mysql_query("SELECT state,about FROM page WHERE page_name='$to'");
    $get_result = mysql_fetch_assoc($about_query);
    $state = $get_result['state'];
    $about_the_page = $get_result['about'];

    echo $about_the_page.'<br/>';
    echo 'State : '.$state;
    
?>
<br />
</div>
