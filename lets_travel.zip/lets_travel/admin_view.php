<?php include ("./inc/connect.inc.php");
session_start();
if (!isset($_SESSION["user_login"])) {
   $user = ""; 
}
else
{
    $user = $_SESSION["user_login"];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Let's Travel</title>
    <link rel="stylesheet" type="text/css" href="/lets_travel/css/style.css" />
    <script src="js/main.js" type="text/javascript"></script>
</head>
<body>

<?php
	echo '
            <ul>
            <img src="./img/lt_menu.png" class="logo"/>  
            <li><a href="logout.php" >Logout</a></li>
            </ul>';

?> 

<?php
$to=$user;
if (isset($_GET['u'])) { 
    $to = mysql_real_escape_string($_GET['u']);  
    if (ctype_alnum($to)) {
    //check user exists
    $check = mysql_query("SELECT id, page_name FROM page WHERE page_name='$to'");
    if (mysql_num_rows($check)===1) {
        $get = mysql_fetch_assoc($check);
        $to = $get['page_name'];
        $id = $get['id'];
    }

    else
    {
        echo "<meta http-eqiuv=\"refresh\" content=\"0; url=http://localhost/lets_travel/index.php>";
        exit();
    }
    }

?>

<?php
  $check_pic = mysql_query("SELECT profile_pic FROM page WHERE page_name='$to'");
  $get_pic_row = mysql_fetch_assoc($check_pic);
  $profile_pic_db = $get_pic_row['profile_pic'];
  if ($profile_pic_db == "") {
  $profile_pic = "img/default_pic.jpg";
  }
  else
  {
  $profile_pic = "pagedata/profile_pics/".$profile_pic_db;
  }

?>

<img src="<?php echo $profile_pic; ?>" height="200" width="200" alt="<?php echo $to; ?>'s Profile" title="<?php echo $to; ?>'s Profile"/>
<br />

<div class="textHeader"><?php echo $to; ?>'s Profile</div>
<div class="profileLeftSideContent">
<?php
    $about_query = mysql_query("SELECT state,about FROM page WHERE page_name='$to'");
    $get_result = mysql_fetch_assoc($about_query);
    $state = $get_result['state'];
    $about_the_page = $get_result['about'];
    echo 'State : '.$state.'<br/>';
    echo 'About : '.$about_the_page;
?>

<br />
</div>
<form action="<?php echo "admin_view.php?u=".$to;?>" method="post">
    <input type="submit" name="accept" value="Accept">&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="submit" name="reject" value="Reject">
</form>

<?php

 if (isset($_POST['accept'])) {

            mysql_query("UPDATE page SET status=1 WHERE page_name='$to'");
            header("location: admin_home.php");
    }
    if (isset($_POST['reject'])) {
            mysql_query("DELETE FROM page WHERE page_name='$to'");
            header("location: admin_home.php");
    }
}
?>