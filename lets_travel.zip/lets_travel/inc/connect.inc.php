<?php
mysql_connect("localhost","root","") or die("Coudn't connect to SQL sever");
mysql_select_db("lets_travel") or die("Coudn't select DB");
?>