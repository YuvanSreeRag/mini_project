<?php include ("./inc/connect.inc.php");
session_start();
if (!isset($_SESSION["user_login"])) {
   $user = ""; 
}
else
{
    $user = $_SESSION["user_login"];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Let's Travel</title>
    <link rel="stylesheet" type="text/css" href="/lets_travel/css/style.css" />
    <script src="js/main.js" type="text/javascript"></script>
</head>
<body>

        <?php
        if (isset($_SESSION["user_login"])) {
        echo '
            <ul>
            <img src="./img/lt_menu.png" class="logo"/>           
            <li><a href="logout.php" >Logout</a></li>
            <li><a href="account_settings.php" >Account Settings</a></li>
            <li><a href="notification.php" >Notification</a></li>
            <li><a href="friend_requests.php" >Friend Requests</a></li>
            <li><a href="profile.php" >Profile</a></li>
            <li><a href="home.php" >Home</a></li>
            <li id="search">
            <form action="search.php" method="post">
            <input type="text" name="query" placeholder="Find Friends or Pages"/>
            <input type="submit" name="search" id="search_button" value="Search" /></a>
            </form>          
            </li>
            </ul>
        ';
        }
        else
        {
            echo '
            <ul>
            <img src="./img/lt_menu.png" class="logo"/>    
            </ul>';
        }
        ?> 
      
        <div id="wrapper">    
        