<?php
include ("./inc/header.inc.php");
?>

<div class="newsFeed">
<h2>Notifications:</h2>
</div>

<?php
$friendsArray = "";
$countFriends = "";
$friendsArray12 = "";
$addAsFriend = "";
$selectFriendsQuery = mysql_query("SELECT friend_array FROM users WHERE username='$user'");
$friendRow = mysql_fetch_assoc($selectFriendsQuery);
$friendArray = $friendRow['friend_array'];
if ($friendArray != "") {
   $friendArray = explode(",",$friendArray);
   $countFriends = count($friendArray);
   $friendArray12 = array_slice($friendArray, 0, 12);

$i = 0;
}
if ($countFriends != 0) {
foreach ($friendArray12 as $key => $value) {
 $i++;

$getposts = mysql_query("SELECT * FROM posts WHERE user_posted_to='$user' and added_by!='$user' ORDER BY pid DESC LIMIT 12") or die(mysql_error());
while ($row = mysql_fetch_assoc($getposts)) {	
	$date_added = $row['date_added'];
	$added_by = $row['added_by'];
	$user_posted_to = $row['user_posted_to'];  

    $get_user_info = mysql_query("SELECT * FROM users WHERE username='$added_by'");
    $get_info = mysql_fetch_assoc($get_user_info);
    $profilepic_info = $get_info['profile_pic'];
    if ($profilepic_info == "") {
     $profilepic_info = "./img/default_pic.jpg";
    }
    else
    {
     $profilepic_info = "./userdata/profile_pics/".$profilepic_info;
    }

    echo  "
	        <p />
	        <div class='notify'>
	        <div style='float: left;'>
	        <img src='$profilepic_info' height='35' width='35'>
	        </div>
	        <b>$added_by</b> posted on your profile
	        <br />
	        $date_added
	        <div  style='max-width: 600px;'>
	        <br /><p /><p />
	        </div>
	       
	        </div>            
	";
	}
}
}
?>