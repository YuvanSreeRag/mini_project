<?php
include ("./inc/header.inc.php");
?>

<?php
if (!isset($_SESSION["user_login"])) {
    echo "<meta http-equiv=\"refresh\" content=\"0; url=http://lets_travel.sinimma.tk/home.php\">";
}
else
{
?>
<div class="newsFeed">
<h2>Newsfeed:</h2>
</div>

<?php
//If the user is logged in
$friendsArray = "";
$countFriends = "";
$friendsArray12 = "";
$addAsFriend = "";
$selectFriendsQuery = mysql_query("SELECT friend_array FROM users WHERE username='$user'");
$friendRow = mysql_fetch_assoc($selectFriendsQuery);
$friendArray = $friendRow['friend_array'];
if ($friendArray != "") {
   $friendArray = explode(",",$friendArray);
   $countFriends = count($friendArray);
   $friendArray12 = array_slice($friendArray, 0, 12);

$i = 0;
}
if ($countFriends != 0) {
foreach ($friendArray12 as $key => $value) {
 $i++;

$getposts = mysql_query("SELECT * FROM posts WHERE added_by in('$user','$value') ORDER BY pid DESC LIMIT 10") or die(mysql_error());
while ($row = mysql_fetch_assoc($getposts)) {
	$id = $row['pid'];
	$body = $row['body'];
    $photo = $row['photo'];	
	$date_added = $row['date_added'];
	$added_by = $row['added_by'];
	$user_posted_to = $row['user_posted_to'];  

    $get_user_info = mysql_query("SELECT * FROM users WHERE username='$added_by'");
    $get_info = mysql_fetch_assoc($get_user_info);
    $profilepic_info = $get_info['profile_pic'];
    if ($profilepic_info == "") {
     $profilepic_info = "./img/default_pic.jpg";
    }
    else
    {
     $profilepic_info = "./userdata/profile_pics/".$profilepic_info;
    }

    if ($photo == "") {  
    echo  "
            <p />
            <div class='newsFeedPost'>
            <div style='float: left;'>
            <img src='$profilepic_info' height='60' width='60'>
            </div>
            <div class='posted_by'>$added_by posted this on $user_posted_to's profile:</div>
            <br /><br />
            <div  style='max-width: 600px;'>
            $body<br /><p /><p />
            </div>
            <br /><br />
            </div>            
	";
    }
    else {
      $photo = "./userdata/user_photos/".$photo;
      echo "
          <p />
            <div class='newsFeedPost'>
            <div style='float: left;'>
            <img src='$profilepic_info' height='60' width='60'>
            </div>
            <div class='posted_by'>$added_by posted a photo on $user_posted_to's profile:</div>
            <br /><br />
            <div  style='max-width: 600px;'>
            <img src='$photo' height='60' width='60'>
            <br /><p /><p />
            </div>
            <br />
            </div>
    ";
    }
}


}
}

}
?>
