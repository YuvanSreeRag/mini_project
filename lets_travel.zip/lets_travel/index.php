<?php include ("./inc/header.inc.php"); ?>
<?php
$reg = @$_POST['reg'];

$fn = "";
$ln = "";
$un = "";
$em = "";
$pswd = "";
$pswd2 = "";
$u_check = "";
$fn = strip_tags(@$_POST['fname']);
$ln = strip_tags(@$_POST['lname']);
$un = strip_tags(@$_POST['username']);
$em = strip_tags(@$_POST['email']);
$pswd = strip_tags(@$_POST['password']);
$pswd2 = strip_tags(@$_POST['password2']);

if ($reg) {
   
    if ($fn&&$ln&&$un&&$em&&$pswd&&$pswd2) {
        $u_check = mysql_query("SELECT username FROM users WHERE username='$un'");
        $check = mysql_num_rows($u_check);
        if($check==0)
        {
            if ($pswd==$pswd2) {
                if (strlen($fn)>25 || strlen($ln)>25) {
                    echo "The maximum limit for first name and lastname is 25 characters";
                }
                else
                {
                    if (strlen($pswd)>20||strlen($pswd)<8) {
                        echo "Your password must be between 8 and 20 characters";
                    }
                    else
                    {
                        $pswd = md5($pswd);
                        $pswd2 = md5($pswd2);
                        $query = mysql_query("INSERT INTO users VALUES ('','$fn','$ln','$un','$em','$pswd','','','','')");
                        echo "Registration completed!";
                        header("location: index.php");
                    }
                }
            }
            else {
                echo "Your password doesn't match!";
            }
        }
        else {
            echo "Username already taken ";
        }
    }
    else {
        echo "Please fill all fields";
    }
}

// User Login Code

if (isset($_POST["user_login"]) && isset($_POST["password_login"])) {
    $user_login = preg_replace('#[^A-Za-z0-9]#i','',$_POST["user_login"]);
    $password_login = preg_replace('#[^A-Za-z0-9]#i','',$_POST["password_login"]);
    $password_login_md5 = md5($password_login);
    $sql = mysql_query("SELECT * FROM users WHERE username='$user_login' AND password='$password_login_md5' LIMIT 1");
    //Check for existence
    $userCount = mysql_num_rows($sql);
    //echo $password_login_md5;
    //echo $userCount;
    if ($userCount == 1) {
        while($row = mysql_fetch_array($sql)){
            $name = $row["username"];
        }
        $_SESSION["user_login"] = $user_login;
        if ($name=='admin') {
            header("location: admin_home.php");
            exit();
        }
        else {
            header("location: home.php");
            exit();
        }
        
    }
    else {
        echo 'That information is incorrect, try again';
        exit();
    }
}

?>
    <h1>Welcome to Let's Travel</h1>
    <div style="width: 800px; margin: 0px auto 0px auto">
    <table style="background color: #000;">
        <tr>
            <td width="60%" valign="top">
                <h2>Already a Member? Sign in Below!</h2>
                <form action="index.php" method="POST">
                    <input type="text" name="user_login" size="25" placeholder="Username" /><br><br>
                    <input type="password" name="password_login" size="25" placeholder="Password" /><br><br>
                    <input type="submit" name="login" value="Login" />
                </form>
            </td>
            <td width="40%" valign="top">
                <h2>Not a Member? Please Sign Up!</h2>
                <form action="index.php" method="POST">
                    <input type="text" name="fname" size="25" placeholder="First Name" /><br><br>
                    <input type="text" name="lname" size="25" placeholder="Last Name" /><br><br>
                    <input type="text" name="username" size="25" placeholder="Username" /><br><br>
                    <input type="text" name="email" size="25" placeholder="Email" /><br><br>
                    <input type="password" name="password" size="25" placeholder="Password" /><br><br>
                    <input type="password" name="password2" size="25" placeholder="Password (again)" /><br><br>
                    <input type="submit" name="reg" value="Sign Up" />
                </form>
            </td>
        </tr>
    </table>
<?php include ("./inc/footer.inc.php"); ?> 