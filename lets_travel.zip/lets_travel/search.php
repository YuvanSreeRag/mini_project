<?php include ("./inc/header.inc.php"); ?>

<div class="newsFeed">
<h2>Search Results:</h2>
</div>

<?php
    $search = @$_POST['search'];
    $query = @$_POST['query'];
    
    if ($search) {    
    $sql = mysql_query("SELECT * FROM users WHERE username='$query' ");
    
    //Check for existence
    $userCount = mysql_num_rows($sql);
    if ($userCount==0) {
        $sql = mysql_query("SELECT * FROM page WHERE page_name='$query' AND status=1");
        $userCount = mysql_num_rows($sql);
        if ($userCount == 1) {
        $get_info = mysql_fetch_assoc($sql);
        $profilepic_info = $get_info['profile_pic'];
        if ($profilepic_info == "") {
         $profilepic_info = "./img/default_pic.jpg";
        }
        else
        {
         $profilepic_info = "./pagedata/profile_pics/".$profilepic_info;
        }

        echo  "
            <p />
            <div class='newsFeedPost'>
            <div style='float: left;'>
            <img src='$profilepic_info' height='60'>
            </div>
            <div class='posted_by'><a href='page.php?u=$query'><h2>$query</h2></a></div>
            <br /><br />
            <div  style='max-width: 600px;'>
            <br /><p /><p />
            </div>
            <br /><br />
            </div>            
        ";

        }
        else {
            echo "<h3>No matches found for $query <br />Do you want to add a page for the required place?</h3>";
        echo "<a href='page_form.php'><h2>Click Here!</h2></a>";
        exit();
        }    
    }
        
    else {
    $get_info = mysql_fetch_assoc($sql);
    $profilepic_info = $get_info['profile_pic'];
    if ($profilepic_info == "") {
     $profilepic_info = "./img/default_pic.jpg";
    }
    else
    {
     $profilepic_info = "./userdata/profile_pics/".$profilepic_info;
    }

    echo  "
        <p />
        <div class='newsFeedPost'>
        <div style='float: left;'>
        <img src='$profilepic_info' height='60'>
        </div>
        <div class='posted_by'><a href='$query'><h2>$query</h2></a></div>
        <br /><br />
        <div  style='max-width: 600px;'>
        <br /><p /><p />
        </div>
        <br /><br />
        </div>            
    ";

    }
    }
?>