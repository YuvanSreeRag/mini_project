<?php include ("./inc/header.inc.php"); ?>

<?php
	$save = @$_POST['save'];
	$page_name="";
	//Submit what user type in to database
    if ($save) {
        $page_name = @$_POST['pname'];
        $state = @$_POST['state'];
        $about = @$_POST['about'];

        //Check whether the user has uploaded a profile pic or not
        $check_pic = mysql_query("SELECT profile_pic FROM page WHERE page_name='$page_name'");
        $get_pic_row = mysql_fetch_assoc($check_pic);
        $profile_pic_db = $get_pic_row['profile_pic'];
        if ($profile_pic_db == "") {
        $profile_pic = "img/default_pic.jpg";
        }
        else
        {
        $profile_pic = "pagedata/profile_pics/".$profile_pic_db;
        }

        //Profile Image upload script
        if (isset($_FILES['profilepic'])) {
         if (((@$_FILES["profilepic"]["type"]=="image/jpeg") || (@$_FILES["profilepic"]["type"]=="image/png") || (@$_FILES["profilepic"]["type"]=="image/gif"))&&(@$_FILES["profilepic"]["size"] < 1048576)) //1 Megabyte
        {
         $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
         $rand_dir_name = substr(str_shuffle($chars), 0, 15);
         mkdir("pagedata/profile_pics/$rand_dir_name",0777,true);

         if (file_exists("pagedata/profile_pics/$rand_dir_name/".@$_FILES["profilepic"]["name"]))
         {
          echo @$_FILES["profilepic"]["name"]." Already exists"; 
         }
         else
         {
          move_uploaded_file(@$_FILES["profilepic"]["tmp_name"],"pagedata/profile_pics/$rand_dir_name/".$_FILES["profilepic"]["name"]);
          //echo "Uploaded and stored in: userdata/profile_pics/$rand_dir_name/".@$_FILES["profilepic"]["name"];
          $profile_pic_name = @$_FILES["profilepic"]["name"];
          //$profile_pic_query = mysql_query("UPDATE page SET profile_pic='$rand_dir_name/$profile_pic_name' WHERE page_name='$page_name'");
          //header("Location: page_form.php");
         
         }
        }
        else
        {
            echo "Invailid File! Your image must be no larger than 1MB and it must be either a .jpg, .jpeg, .png or .gif";
        }
        }
    
        $n_check = mysql_query("SELECT page_name FROM page WHERE page_name='$page_name'");
		$check = mysql_num_rows($n_check);
		if ($check == 1) {
			echo "Page already exists!";
		}
		else {
			//Submit the form to the database
        	$info_submit_query =mysql_query("INSERT INTO page VALUES ('','$page_name','$state','$about','$rand_dir_name/$profile_pic_name',0,'') ");
        	echo "Your Page information has been updated. Please wait for the admin verification";
		}       
    }
    else
    {
        //Do nothing
    }

?>

<h2>Add Place Details</h2>
<hr /><br />
<p>UPLOAD PROFILE PHOTO:</p> <br />
<form action="page_form.php" method="POST" enctype="multipart/form-data">
<img src="<?php echo $profile_pic; ?>" width="70" />
<input type="file" name="profilepic" /><br /><br />
Place Name: <input type="text" name="pname" id="pname" size="40" ><br />
State: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="state" id="state" size="40" ><br />
About Place: <textarea name="about" id="about" rows="7" cols="56"></textarea><br />
<input type="submit" name="save" id="save" value="Save Information"> 
</form>
<hr />