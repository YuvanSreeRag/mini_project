<?php
include ("./inc/header.inc.php");
if ($user) {
    
}
else
{
    die ("You must be logged in to view this page!");
}
?>
<?php
    $senddata = @$_POST['senddata'];
    
    $old_password = @$_POST['oldpassword'];
    $new_password = @$_POST['newpassword'];
    $repeat_password = @$_POST['newpassword2'];
    
    if ($senddata) {
        //if the form has been submitted...
    
        $password_query = mysql_query("SELECT * FROM users WHERE username='$user'");
        while ($row = mysql_fetch_assoc($password_query)) {
            $db_password = $row['password'];
             $old_password_md5 = md5($old_password);
            
            //check whether old password equals $db_password
            if ($old_password_md5 == $db_password) {
                 
            if ($new_password == $repeat_password) {
                if (strlen($new_password)<=7){
                    echo "Sorry! Password must be more than 8 characters";
                }
                else
                {
                $new_password_md5 = md5($new_password);
                $password_update_query = mysql_query("UPDATE users SET password='$new_password_md5' WHERE username='$user'");
                echo "Success! Your password has been updated";
                }
            }
            else
            {
                echo "Your two new passwords doesn't match";
            }
            }
            else
            {
                echo "The old password is incorrect";    
            }
        }
    }
    else
    {
        echo "";
    }
     
    $updateinfo = @$_POST['updateinfo']; 

    //First name, Last name and About the user query
    $get_info = mysql_query("SELECT first_name, last_name, bio FROM users WHERE username='$user'");
    $get_row = mysql_fetch_assoc($get_info);
    $db_first_name = $get_row['first_name'];
    $db_last_name = $get_row['last_name']; 
    $db_bio = $get_row['bio'];
    
    //Submit what user type in to database
    if ($updateinfo) {
        $firstname = @$_POST['fname'];
        $lastname = @$_POST['lname'];
        $bio = @$_POST['bio'];
    
        //Submit the form to the database
        $info_submit_query =mysql_query("UPDATE users SET first_name='$firstname', last_name='$lastname', bio='$bio' WHERE username='$user'");
        echo "Your Profile information has been updated";
       // header("Location: profile.php?id=$username");
    }
    else
    {
        //Do nothing
    }

 //Check whether the user has uploaded a profile pic or not
  $check_pic = mysql_query("SELECT profile_pic FROM users WHERE username='$user'");
  $get_pic_row = mysql_fetch_assoc($check_pic);
  $profile_pic_db = $get_pic_row['profile_pic'];
  if ($profile_pic_db == "") {
  $profile_pic = "img/default_pic.jpg";
  }
  else
  {
  $profile_pic = "userdata/profile_pics/".$profile_pic_db;
  }

//Profile Image upload script
  if (isset($_FILES['profilepic'])) {
   if (((@$_FILES["profilepic"]["type"]=="image/jpeg") || (@$_FILES["profilepic"]["type"]=="image/png") || (@$_FILES["profilepic"]["type"]=="image/gif"))&&(@$_FILES["profilepic"]["size"] < 1048576)) //1 Megabyte
  {
   $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
   $rand_dir_name = substr(str_shuffle($chars), 0, 15);
   mkdir("userdata/profile_pics/$rand_dir_name",0777,true);

   if (file_exists("userdata/profile_pics/$rand_dir_name/".@$_FILES["profilepic"]["name"]))
   {
    echo @$_FILES["profilepic"]["name"]." Already exists"; 
   }
   else
   {
    move_uploaded_file(@$_FILES["profilepic"]["tmp_name"],"userdata/profile_pics/$rand_dir_name/".$_FILES["profilepic"]["name"]);
    //echo "Uploaded and stored in: userdata/profile_pics/$rand_dir_name/".@$_FILES["profilepic"]["name"];
    $profile_pic_name = @$_FILES["profilepic"]["name"];
    $profile_pic_query = mysql_query("UPDATE users SET profile_pic='$rand_dir_name/$profile_pic_name' WHERE username='$user'");
    header("Location: account_settings.php");
   
   }
  }
  else
  {
      echo "Invailid File! Your image must be no larger than 1MB and it must be either a .jpg, .jpeg, .png or .gif";
  }
  }



?>
<h2>Edit your Account Settings below</h2>
<hr /><br />
<p>UPLOAD YOUR PROFILE PHOTO:</p> <br />
<form action="" method="POST" enctype="multipart/form-data">
<img src="<?php echo $profile_pic; ?>" width="70" />
<input type="file" name="profilepic" /><br />
<input type="submit" name="uploadpic" value="Upload Image">
</form>
<hr /><br />

<form action="account_settings.php" method="post">
<p>CHANGE YOUR PASSWORD:</p> <br />
Your Old Password &nbsp;&nbsp;<input type="text" name="oldpassword" id="oldpassword" size="30"><br />
Your New Password <input type="text" name="newpassword" id="newpassword" size="30"><br />
Repeat Password &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="newpassword2" id="newpassword2" size="30"><br />
<input type="submit" name="senddata" id="senddata" value="Change Password"><br />
</form>
<hr /><br />

<form action="account_settings.php" method="post">
<p>UPDATE YOUR PROFILE INFO:</p> <br />
First Name: <input type="text" name="fname" id="fname" size="40" value="<?php echo $db_first_name; ?>"><br />
Last Name: <input type="text" name="lname" id="lname" size="40" value="<?php echo $db_last_name; ?>"><br />
About You: <textarea name="bio" id="bio" rows="7" cols="56"><?php echo $db_bio;?></textarea><br />
<input type="submit" name="updateinfo" id="updateinfo" value="Update Information"> 
</form>
<hr />