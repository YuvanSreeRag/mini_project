<?php include ("./inc/header.inc.php"); ?>
<?php
$to=$user;
if (isset($_GET['u'])) { 
    $to = mysql_real_escape_string($_GET['u']);  
    if (ctype_alnum($to)) {
    //check user exists
    $check = mysql_query("SELECT username, first_name FROM users WHERE username='$to'");
    if (mysql_num_rows($check)===1) {
        $get = mysql_fetch_assoc($check);
        $to = $get['username'];
        $firstname = $get['first_name'];
    }

    else
    {
        echo "<meta http-eqiuv=\"refresh\" content=\"0; url=http://localhost/lets_travel/index.php>";
        exit();
    }
    }
}

$post = @$_POST['post'];
if ($post != "") {
    $date_added = date("Y-m-d");
    $added_by = $user;
    $user_posted_to = $to;
    
    $sqlCommand = "INSERT INTO posts VALUES('','$post','','$date_added','$added_by','$user_posted_to')";
    $query = mysql_query($sqlCommand) or die(mysql_error());
}

//upload image code 
if (isset($_POST['uploadpic'])) {
        if (((@$_FILES["profilepic"]["type"]=="image/jpeg") || (@$_FILES["profilepic"]["type"]=="image/png") || (@$_FILES["profilepic"]["type"]=="image/gif"))&&(@$_FILES["profilepic"]["size"] < 1048576)) //1 Megabyte
  {
   $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
   $rand_dir_name = substr(str_shuffle($chars), 0, 15);
   mkdir("userdata/user_photos/$rand_dir_name",0777,true);

   if (file_exists("userdata/user_photos/$rand_dir_name/".@$_FILES["profilepic"]["name"]))
   {
    echo @$_FILES["profilepic"]["name"]." Already exists";
   }
   else
   {
    move_uploaded_file(@$_FILES["profilepic"]["tmp_name"],"userdata/user_photos/$rand_dir_name/".$_FILES["profilepic"]["name"]);
    //echo "Uploaded and stored in: userdata/profile_pics/$rand_dir_name/".@$_FILES["profilepic"]["name"];
    $profile_pic_name = @$_FILES["profilepic"]["name"];
    $img_id = "$rand_dir_name/$profile_pic_name";

    $date_added = date("Y-m-d");
    $added_by = $user;
    $user_posted_to = $to;
    
    $sqlCommand = "INSERT INTO posts VALUES('','','$img_id','$date_added','$added_by','$user_posted_to')";
    $query = mysql_query($sqlCommand) or die(mysql_error());
   }
}
}

 //Check whether the user has uploaded a profile pic or not
//changed from $user to $to
  $check_pic = mysql_query("SELECT profile_pic FROM users WHERE username='$to'");
  $get_pic_row = mysql_fetch_assoc($check_pic);
  $profile_pic_db = $get_pic_row['profile_pic'];
  if ($profile_pic_db == "") {
  $profile_pic = "img/default_pic.jpg";
  }
  else
  {
  $profile_pic = "userdata/profile_pics/".$profile_pic_db;
  }
 
?>
<div id="status"></div>
<div class="postForm">
<form action="<?php echo $to; ?>" method="POST">    
    <textarea id="post" name="post" rows="4" cols="90"></textarea>
    <input type="submit" name="send" value="post" style="background-color: #DCE5EE; float: right; border: 1px solid #666; color:#666; height:73px; width:65px;"/>
</form>

<form action="" method="POST" enctype="multipart/form-data">
<input type="file" name="profilepic" />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="uploadpic" value="Upload Image">
</form>
</div>
<div class="profilePosts">
<?php
//changed from $user to $to
$getposts = mysql_query("SELECT * FROM posts WHERE user_posted_to='$to' ORDER BY pid DESC LIMIT 10") or die (mysql_error())  ;
while ($row = mysql_fetch_assoc($getposts)) {
    $pid = $row['pid'];
    $body = $row['body'];
    $photo = $row['photo'];
    $date_added = $row['date_added'];
    $added_by = $row['added_by'];
    $user_posted_to = $row['user_posted_to'];

    $get_user_info = mysql_query("SELECT * FROM users WHERE username='$added_by'");
    $get_info = mysql_fetch_assoc($get_user_info);
    $profilepic_info = $get_info['profile_pic'];
    if ($profilepic_info == "") {
     $profilepic_info = "./img/default_pic.jpg";
    }
    else
    {
     $profilepic_info = "./userdata/profile_pics/".$profilepic_info;
    }

    if ($photo == "") {    
    echo "
          <div style='float: left;'>
          <img src='$profilepic_info' height='60' width='60'>
          </div>
          <div class='posted_by'>
          Posted by:
          <a href='$added_by'>$added_by</a> on $date_added</div>
          <br /><br />
          <div  style='max-width: 600px;'>
          $body<br /><p /><p />
          </div>
          <br /><br />
          <hr />
    ";
    }
    else {
      $photo = "./userdata/user_photos/".$photo;
      echo "
          <div style='float: left;'>
          <img src='$profilepic_info' height='60' width='60'>
          </div>
          <div class='posted_by'>
          Posted by:
          <a href='$added_by'>$added_by</a> on $date_added</div>
          <br /><br />
          <div  style='max-width: 600px;'>
          <img src='$photo' height='60' width='60'>
          <br /><p /><p />
          </div>
          <br />
          <hr />
    ";
    }
}

$errorMsg = "";
  if (isset($_POST['addfriend'])) {
     $friend_request = $_POST['addfriend'];
     
     $user_from = $user;
     $user_to = $to;
     
     if ($user_from == $to) {
      $errorMsg = "You can't send a friend request to yourself!<br />";
     }
     else
     {
      $create_request = mysql_query("INSERT INTO friend_requests VALUES ('','$user_from','$user_to')");
      $errorMsg = "Your friend Request has been sent!";
     }

  }
  else
  {
   //Do nothing
  }
?>


</div>
<img src="<?php echo $profile_pic; ?>" height="200" width="200" alt="<?php echo $to; ?>'s Profile" title="<?php echo $to; ?>'s Profile"/>
<br />
<form action="<?php echo $to; ?>" method="POST">
<?php
$friendsArray = "";
$countFriends = "";
$friendsArray12 = "";
$addAsFriend = "";
$selectFriendsQuery = mysql_query("SELECT friend_array FROM users WHERE username='$to'");
$friendRow = mysql_fetch_assoc($selectFriendsQuery);
$friendArray = $friendRow['friend_array'];
if ($friendArray != "") {
   $friendArray = explode(",",$friendArray);
   $countFriends = count($friendArray);
   $friendArray12 = array_slice($friendArray, 0, 12);

$i = 0;
if (in_array($user,$friendArray)) {
 $addAsFriend = '<input type="submit" name="removefriend" value="UnFriend">';
}
else
{ 
 $addAsFriend = '<input type="submit" name="addfriend" value="Add Friend">';
} 
echo $addAsFriend;
}
else
{
 $addAsFriend = '<input type="submit" name="addfriend" value="Add Friend">';
 echo $addAsFriend;
}
//$user = logged in user
//$to = user who owns profile
if (@$_POST['removefriend']) {
  //Friend array for logged in user
  $add_friend_check = mysql_query("SELECT friend_array FROM users WHERE username='$user'");
  $get_friend_row = mysql_fetch_assoc($add_friend_check);
  $friend_array = $get_friend_row['friend_array'];
  $friend_array_explode = explode(",",$friend_array);
  $friend_array_count = count($friend_array_explode);
  
  //Friend array for user who owns profile
  $add_friend_check_username = mysql_query("SELECT friend_array FROM users WHERE username='$to'");
  $get_friend_row_username = mysql_fetch_assoc($add_friend_check_username);
  $friend_array_username = $get_friend_row_username['friend_array'];
  $friend_array_explode_username = explode(",",$friend_array_username);
  $friend_array_count_username = count($friend_array_explode_username);
  
  $usernameComma = ",".$to;
  $usernameComma2 = $to.",";
  
  $userComma = ",".$user;
  $userComma2 = $user.",";
  
  if (strstr($friend_array,$usernameComma)) {
   $friend1 = str_replace("$usernameComma","",$friend_array);
  }
  else
  if (strstr($friend_array,$usernameComma2)) {
   $friend1 = str_replace("$usernameComma2","",$friend_array);
  }
  else
  if (strstr($friend_array,$to)) {
   $friend1 = str_replace("$to","",$friend_array);
  }
  //Remove logged in user from other persons array
  if (strstr($friend_array,$userComma)) {
   $friend2 = str_replace("$userComma","",$friend_array);
  }
  else
  if (strstr($friend_array,$userComma2)) {
   $friend2 = str_replace("$userComma2","",$friend_array);
  }
  else
  if (strstr($friend_array,$user)) {
   $friend2 = str_replace("$user","",$friend_array);
  }

  $friend2 = "";

  $removeFriendQuery = mysql_query("UPDATE users SET friend_array='$friend1' WHERE username='$user'");
  $removeFriendQuery_username = mysql_query("UPDATE users SET friend_array='$friend2' WHERE username='$to'");
  echo "Friend Removed ...";
  header("Location: $to");
}
?>
<?php echo $errorMsg; ?>

</form>

<div class="textHeader"><?php echo $to; ?>'s Profile</div>
<div class="profileLeftSideContent">
<?php
//changed from $user to $to
    $about_query = mysql_query("SELECT bio FROM users WHERE username='$to'");
    $get_result = mysql_fetch_assoc($about_query);
    $about_the_user = $get_result['bio'];
    
    echo $about_the_user;
?>
<br />
</div>
<div class="textHeader"><?php echo $to; ?>'s Friends</div>
<div class="profileLeftSideContent">
<?php
if ($countFriends != 0) {
foreach ($friendArray12 as $key => $value) {
 $i++;
 $getFriendQuery = mysql_query("SELECT * FROM users WHERE username='$value' LIMIT 1");
 $getFriendRow = mysql_fetch_assoc($getFriendQuery);
 $friendUsername = $getFriendRow['username'];
 $friendProfilePic = $getFriendRow['profile_pic'];

 if ($friendProfilePic == "") {
  echo "<a href='$friendUsername'><img src='img/default_pic.jpg' alt=\"$friendUsername's Profile\" title=\"$friendUsername's Profile\" height='55' width='55' style='padding-right: 7px;'></a>";
 }
 else
 {
  echo "<a href='$friendUsername'><img src='userdata/profile_pics/$friendProfilePic' alt=\"$friendUsername's Profile\" title=\"$friendUsername's Profile\" height='55' width='55' style='padding-right: 7px;'></a>
  ";
 }
}
}
else
echo $to." has no friends yet.";
?>