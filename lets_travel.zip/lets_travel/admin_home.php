<?php include ("./inc/connect.inc.php");
session_start();
if (!isset($_SESSION["user_login"])) {
   $user = ""; 
}
else
{
    $user = $_SESSION["user_login"];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Let's Travel</title>
    <link rel="stylesheet" type="text/css" href="/lets_travel/css/style.css" />
    <script src="js/main.js" type="text/javascript"></script>
</head>
<body>

<?php
	echo '
            <ul>
            <img src="./img/lt_menu.png" class="logo"/>  
            <li><a href="logout.php" >Logout</a></li>
            </ul>';
    echo '<h2>Newly added pages:</h2>';

    $sql = mysql_query("SELECT * FROM page WHERE status=0");
		
        while ($get_info = mysql_fetch_assoc($sql)) {
       
        $pagename = $get_info['page_name'];
        $profilepic_info = $get_info['profile_pic'];
        if ($profilepic_info == "") {
         $profilepic_info = "./img/default_pic.jpg";
        }
        else
        {
         $profilepic_info = "./pagedata/profile_pics/".$profilepic_info;
        }

        
        echo  "
            <p />
            <div class='newsFeedPost'>
            <div style='float: left;'>
            <img src='$profilepic_info' height='60'>
            </div>
            <div class='posted_by'><a href='admin_view.php?u=$pagename'><h2>$pagename</h2></a></div>
            <br /><br />
            <div  style='max-width: 600px;'>
            <br /><p /><p />
            </div>
            <br /><br />
            </div>            
        ";

        }

?>